# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### Moona Crochet (`artifacts/moona-crochet`)
- **Type**: React + Vite web app
- **Preview path**: `/`
- **Description**: Handmade crochet e-commerce store

**Pages:**
- `/` — Homepage with hero, product previews
- `/keychains` — Keychain product grid (6 items)
- `/flowers` — Flower product grid (4 items)
- `/cart` — Cart with quantity controls
- `/checkout` — Checkout form (name, phone, address)
- `/order-confirmation/:id` — Post-order confirmation
- `/admin` — Admin dashboard with order list and stats

**Features:**
- Cart persists in localStorage via CartContext
- Orders saved to PostgreSQL via API
- Pastel pink/cream/beige theme with Playfair Display + DM Sans fonts

### API Server (`artifacts/api-server`)
- **Type**: Express 5 API server
- **Routes**: `/api/products`, `/api/orders`, `/api/orders/summary`, `/api/healthz`

## Database Schema

- **products**: id, name, price, category (keychains|flowers), imageUrl, description
- **orders**: id, customerName, phone, address, items (jsonb), total, status, createdAt

## Seeded Products

**Keychains:** Star (PKR 300), Heart (PKR 300), Tulip Flower (PKR 400), Sunflower (PKR 300), Bow (PKR 300), Crochet Mini (PKR 250)

**Flowers:** Sunflower (PKR 350), Tulip (PKR 350), Rose (PKR 400), Lily (PKR 350)
