# 🚀 Moona Crochet Shop - Deploy Guide

## FILES JO REPLACE KARNE HAIN

| Yeh file download karo | Apne project mein yahan paste karo |
|---|---|
| `vite.config.ts` | `artifacts/moona-crochet/vite.config.ts` |
| `main.tsx` | `artifacts/moona-crochet/src/main.tsx` |
| `netlify.toml` | Root folder mein (sabse upar) |
| `api-index.ts` | `artifacts/api-server/src/index.ts` |

---

## PART 1: GitHub pe Code Upload

1. **github.com** pe jao → Sign up / Login
2. Green **"New"** button → Repository name: `moona-crochet-shop`
3. **"uploading an existing file"** click karo
4. Zip extract karo → Moona-Crochet-Shop folder ka saara content drag karo
5. **"Commit changes"** click karo

---

## PART 2: Railway pe Backend + Database

### Database Setup:
1. **railway.app** → Login with GitHub
2. **"New Project"** → **"Deploy PostgreSQL"**
3. Database click karo → **"Variables"** tab → `DATABASE_URL` copy karo ✅

### API Server Setup:
1. Railway project mein → **"+ New"** → **"GitHub Repo"**
2. Apna `moona-crochet-shop` repo select karo
3. **Settings** tab:
   - Root Directory: `artifacts/api-server`
   - Start Command: `node dist/index.mjs`
4. **Variables** tab, yeh add karo:
   ```
   DATABASE_URL    = (woh jo PostgreSQL ne diya)
   ADMIN_USERNAME  = admin
   ADMIN_PASSWORD  = (apna strong password)
   PORT            = 3001
   NODE_ENV        = production
   ```
5. **Deploy** → Deploy hone ka wait karo
6. **Settings** → **Domains** → **"Generate Domain"** → URL copy karo
   Example: `https://moona-api-production.railway.app`

### Database Seed (Products add karo):
Railway mein API service → **Shell** tab:
```bash
cd artifacts/api-server
node -e "
const { db } = require('../../lib/db/dist/index.js');
// Products automatically seed honge jab API pehli baar start ho
console.log('DB ready!');
"
```

---

## PART 3: Netlify pe Frontend

1. **netlify.com** → Login with GitHub
2. **"Add new site"** → **"Import an existing project"**
3. GitHub connect karo → `moona-crochet-shop` select karo
4. Build settings (automatically detect ho jayenge `netlify.toml` se) ✅
5. **Environment variables** add karo:
   ```
   VITE_API_URL = https://moona-api-production.railway.app
   ```
   (woh Railway URL jo aapne upar copy kiya)
6. **"Deploy site"** → 2-3 minute wait karo 🎉

---

## DEPLOY KE BAAD TEST KARO

- ✅ Homepage khul rahi hai?
- ✅ Products dikh rahe hain?
- ✅ Cart kaam kar rahi hai?
- ✅ Checkout order save ho raha hai?
- ✅ Admin login: `https://aapki-site.netlify.app/admin/login`

---

## PROBLEM AAI? YEH CHECK KARO

**Products nahi dikh rahe:**
→ Railway mein DATABASE_URL sahi hai?
→ API server ke logs check karo (Railway dashboard → Deployments → Logs)

**CORS error console mein:**
→ `VITE_API_URL` mein trailing slash `/` nahi hona chahiye

**Build fail:**
→ Netlify Logs mein dekho kya error hai
