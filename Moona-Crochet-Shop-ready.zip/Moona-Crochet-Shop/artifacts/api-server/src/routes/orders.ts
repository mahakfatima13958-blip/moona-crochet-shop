import { Router, type IRouter } from "express";
import { eq, desc, sum, count } from "drizzle-orm";
import { db, productsTable, ordersTable } from "@workspace/db";
import {
  CreateOrderBody,
  GetOrderParams,
  ListOrdersResponse,
  GetOrderResponse,
  GetOrderSummaryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/orders/summary", async (req, res): Promise<void> => {
  const [totals] = await db
    .select({
      totalOrders: count(),
      totalRevenue: sum(ordersTable.total),
    })
    .from(ordersTable);

  const [pending] = await db
    .select({ pendingOrders: count() })
    .from(ordersTable)
    .where(eq(ordersTable.status, "pending"));

  const recentRaw = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt))
    .limit(5);

  const recentOrders = recentRaw.map((o) => ({
    ...o,
    total: Number(o.total),
    items: o.items as { productId: number; productName: string; quantity: number; price: number }[],
  }));

  res.json(
    GetOrderSummaryResponse.parse({
      totalOrders: Number(totals?.totalOrders ?? 0),
      totalRevenue: Number(totals?.totalRevenue ?? 0),
      pendingOrders: Number(pending?.pendingOrders ?? 0),
      recentOrders,
    })
  );
});

router.get("/orders", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt));

  res.json(
    ListOrdersResponse.parse(
      rows.map((o) => ({
        ...o,
        total: Number(o.total),
        items: o.items as { productId: number; productName: string; quantity: number; price: number }[],
      }))
    )
  );
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { customerName, phone, address, items: orderItems } = parsed.data;

  const productIds = orderItems.map((i) => i.productId);
  const products = await db
    .select()
    .from(productsTable)
    .where(
      productIds.length === 1
        ? eq(productsTable.id, productIds[0])
        : eq(productsTable.id, productIds[0])
    );

  const allProducts = await db.select().from(productsTable);
  const productMap = new Map(allProducts.map((p) => [p.id, p]));

  let total = 0;
  const resolvedItems: { productId: number; productName: string; quantity: number; price: number }[] = [];

  for (const item of orderItems) {
    const product = productMap.get(item.productId);
    if (!product) {
      res.status(400).json({ error: `Product ${item.productId} not found` });
      return;
    }
    const price = Number(product.price);
    resolvedItems.push({
      productId: product.id,
      productName: product.name,
      quantity: item.quantity,
      price,
    });
    total += price * item.quantity;
  }

  const [order] = await db
    .insert(ordersTable)
    .values({
      customerName,
      phone,
      address,
      items: resolvedItems,
      total: total.toFixed(2),
      status: "pending",
    })
    .returning();

  res.status(201).json(
    GetOrderResponse.parse({
      ...order,
      total: Number(order.total),
      items: order.items as { productId: number; productName: string; quantity: number; price: number }[],
    })
  );
});

router.get("/orders/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetOrderParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, params.data.id));

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json(
    GetOrderResponse.parse({
      ...order,
      total: Number(order.total),
      items: order.items as { productId: number; productName: string; quantity: number; price: number }[],
    })
  );
});

export default router;
