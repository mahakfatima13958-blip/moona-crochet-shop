import { Router, type IRouter } from "express";
import { createHmac, timingSafeEqual } from "crypto";

const router: IRouter = Router();

function computeToken(): string {
  const secret = process.env.SESSION_SECRET ?? "dev-secret";
  return createHmac("sha256", secret).update("admin-session-v1").digest("hex");
}

function safeEqual(a: string, b: string): boolean {
  try {
    return timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}

router.post("/admin/login", (req, res): void => {
  const { username, password } = req.body as { username?: string; password?: string };

  const expectedUser = process.env.ADMIN_USERNAME ?? "admin";
  const expectedPass = process.env.ADMIN_PASSWORD ?? "moona2024";

  const userOk = safeEqual(username ?? "", expectedUser);
  const passOk = safeEqual(password ?? "", expectedPass);

  if (userOk && passOk) {
    res.json({ token: computeToken() });
  } else {
    res.status(401).json({ error: "Invalid username or password" });
  }
});

router.get("/admin/verify", (req, res): void => {
  const auth = req.headers.authorization ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (token && safeEqual(token, computeToken())) {
    res.json({ ok: true });
  } else {
    res.status(401).json({ error: "Unauthorized" });
  }
});

export default router;
